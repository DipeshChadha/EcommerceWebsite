from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(contact)
admin.site.register(signup)
admin.site.register(category)
admin.site.register(products)
admin.site.register(cart)
admin.site.register(cartItems)
admin.site.register(Order)
# admin.site.register(query)