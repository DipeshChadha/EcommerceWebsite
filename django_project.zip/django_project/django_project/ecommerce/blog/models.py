from django.db import models
from django.utils.translation import gettext_lazy as _
from .constants import PaymentStatus


class contact(models.Model):
    Name = models.CharField(max_length=20, default=False)
    Email = models.EmailField(default=False)
    Message = models.TextField(default=False)

    def __str__(self):
        return self.Name


# Create your models here.
class signup(models.Model):
    name = models.CharField(max_length=20)
    email = models.EmailField(default=False)
    passw = models.TextField(max_length=12)
    cont = models.IntegerField(default=False)

    def __str__(self):
        return self.name


class category(models.Model):
    sno = models.AutoField
    name = models.CharField(max_length=20, null=False)
    description = models.TextField(max_length=400, null=False, blank=False)
    status = models.BooleanField(default=False, help_text="0-show,1-Hidden")
    created_at = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='upload/', null=True, blank=True)

    def __str__(self):
        return self.name


class products(models.Model):
    cat = models.ForeignKey(category, on_delete=models.CASCADE)
    sno = models.AutoField
    name = models.CharField(max_length=20, null=False)
    description = models.TextField(max_length=400, null=False, blank=False)
    sales_price = models.IntegerField()
    original_price = models.IntegerField()
    image = models.ImageField(upload_to='upload/', null=True, blank=True)

    def __str__(self):
        return self.name


class cart(models.Model):
    products = models.ManyToManyField(products, through='cartItems')
    user = models.ForeignKey(signup, on_delete=models.CASCADE)

    def __str__(self):
        return self.user.name


class cartItems(models.Model):
    product = models.ForeignKey(products, on_delete=models.CASCADE)
    cart = models.ForeignKey(cart, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return self.product.name


class Order(models.Model):
    name = models.CharField(_("Customer Name"), max_length=254, blank=False, null=False)
    amount = models.FloatField(_("Amount"), null=False, blank=False)
    status = models.CharField(_("Payment Status"),

                              default=PaymentStatus.PENDING,
                              max_length=254,
                              blank=False,
                              null=False,
                              )
    provider_order_id = models.CharField(("Order ID"), max_length=40, null=False, blank=False)
    payment_id = models.CharField(("Payment ID"), max_length=36, null=False, blank=False)
    signature_id = models.CharField(("Signature ID"), max_length=128, null=False, blank=False)
