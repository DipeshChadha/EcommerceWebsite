from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.home),
    # path('index/', views.index),
    path('mainindex/', views.mainindex, name="mainindex"),
    path('contact/', views.contact1, name="contact"),
    path('signup/', views.signup1, name="signup"),
    path('login/', views.login1, name="login"),
    path('logout/', views.logout_view, name="logout"),
    path('category/', views.category12, name="category"),
    path('products/<str:name>', views.products12, name="products"),
    path('product_detail/<str:cname>/<str:pname>', views.products_detail12, name="product_detail"),
    path('cart/<int:id>', views.addto_cart, name="cart"),
    path('view-cart/', views.viewCart, name="vcart"),
    path('search/', views.search1, name="search"),
    path('payment/', views.order_payment, name='payment'),
    path('delFromCart/<int:id>', views.delFromCart, name='delFromCart'),

]
