from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
# Create your views here.

import razorpay, json
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from .models import *


def home(request):
    return HttpResponse("this is my home page")


# def index(request):
# return render(request,"blog/index.html")


def mainindex(request):
    return render(request, "blog/mainindex.html")


def contact1(request):
    if request.method == "POST":
        name1 = request.POST['name']
        email1 = request.POST['email']
        # subject1 = request.POST['Subject']
        message1 = request.POST['message']
        contact.objects.create(Name=name1, Email=email1, Message=message1)
        msg = "Query sent successfully"
        return render(request, "blog/contact.html", {'msg': msg})
    return render(request, "blog/contact.html")


def signup1(request):
    if request.method == "POST":
        name = request.POST['sname']
        email = request.POST['semail']
        passw = request.POST['spassw']
        cont = request.POST['scontact']
        q = signup.objects.filter(email=email)
        if q:
            msg = "Email id already exist:"
            return render(request, "blog/signup.html", {"already_exist": msg})
        else:
            signup.objects.create(name=name, email=email, passw=passw, cont=cont)
            return render(request, "blog/signup.html")
    return render(request, "blog/signup.html")

def login1(request):
    if request.method == "POST":
        email = request.POST['email']
        passw = request.POST['passw']
        user_query = signup.objects.filter(email=email)

        if user_query.exists():
            qu = signup.objects.get(email=email)
            if qu.passw == passw:
                request.session['email'] = email
                print("email stored in session", email)
                return redirect('mainindex')
            else:
                msg = "Wrong password"
                return render(request, "blog/login.html", {"msg": msg})
        else:
            msg = "User not found"
            return render(request, "blog/login.html", {"msg": msg})

    return render(request, "blog/login.html")


def logout_view(request):
    if 'email' in request.session:
        del request.session['email']
    return redirect('../mainindex')


def show_session(request):
    username = request.session['email']
    return render(request, "blog/mainindex.html", {'username': username})


def category12(request):
    prod = category.objects.all()
    return render(request, "blog/category.html", {"prod": prod})


def products12(request, name):
    if (category.objects.filter(name=name)):
        prod = products.objects.filter(cat__name=name)
        return render(request, "blog/products.html", {"prod": prod, 'cat_name': name})
    return render(request, "blog/category.html")
    # if category.objects.filter(name=name):
    # prod=products.objects.all()
    # return render(request,"blog/products.html",{"prod":prod})


def products_detail12(request, cname, pname):
    if (category.objects.filter(name=cname)):
        if products.objects.filter(name=pname):
            prod = products.objects.filter(name=pname).first()
            return render(request, "blog/product_detail.html", {"prod": prod})
    return render(request, "blog/product_detail.html")


def addto_cart(request, id):
    if 'email' in request.session:
        email1 = request.session['email']
        user1 = signup.objects.filter(email=email1).first()
        product = products.objects.get(id=id)

        if user1:
            # Check if the user already has a cart
            user_cart = cart.objects.filter(user=user1).first()
            if not user_cart:
                # Create a new cart if the user doesn't have one
                user_cart = cart.objects.create(user=user1)

            if product in user_cart.products.all():
                return HttpResponse("Item already exists in the cart.")
            else:
                user_cart.products.add(product)
                return redirect('vcart')  # Redirect to the cart page or any other appropriate URL
        else:
            return HttpResponse("User not found.")  # Handle case where user is not found
    else:
        return redirect('mainindex')  # Redirect to the main index page if user session doesn't exist


def viewCart(request):
    if 'email' in request.session:
        em1 = request.session['email']
        user1 = signup.objects.get(email=em1)
        cart_items = cartItems.objects.filter(cart__user=user1)

        if request.method == 'POST':
            item_id = request.POST.get('item_id')
            quantity_change = request.POST.get('quantity_change')

            try:
                quantity_change_int = int(quantity_change)
            except (ValueError, TypeError):
                # Handle cases where quantity_change is not a valid integer
                return redirect('vcart')

            # Update the quantity for the specified item
            cart_item = cartItems.objects.get(id=item_id)
            cart_item.quantity += quantity_change_int
            if cart_item.quantity < 1:
                cart_item.quantity = 1  # Ensure quantity doesn't go below 1
            else:
                cart_item.save()

            return redirect('vcart')

        total_price = 0
        for item in cart_items:
            item.total_price = item.quantity * item.product.sales_price
            total_price += item.total_price
            request.session['total_price'] = total_price

        return render(request, 'blog/cart.html', {'cart_items': cart_items, 'user': user1, 'total_price': total_price})

    return render(request, 'blog/cart.html')


def delFromCart(request, id):
    cart_item = get_object_or_404(cartItems, id=id)
    cart_item.delete()
    return redirect('vcart')


def updateCart(request):
    if request.method == "POST":
        cart_item_id = request.POST.get('cart_item_id')
        quantity = request.POST.get('quantity', 1)
        cart_item = get_object_or_404(cartItems, id=cart_item_id)
        cart_item.quantity = quantity
        cart_item.save()
        return redirect('vcart')
    return HttpResponse("Method not allowed")


def search1(request):
    q = request.GET['q']
    data = products.objects.filter(name__icontains=q)
    return render(request, "blog/search.html", {"data": data})


def order_payment(request):
    if 'email' in request.session:
        total_price1 = request.session['total_price']
        cu = request.session['email']
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        payment_order = client.order.create(
            {"amount": int(total_price1) * 100, "currency": "INR", "payment_capture": "1"})
        order = Order.objects.create(
            name=cu, amount=int(total_price1), provider_order_id=payment_order["id"]
        )
        order.save()
        return render(
            request,
            "blog/payment1.html",
            {
                "callback_url": "http://" + "127.0.0.1:8000" + "/shop/callback/" + cu,
                "razorpay_key": settings.RAZORPAY_KEY_ID,
                "order": order,
            },
        )
    return render(request, "blog/payment1.html")

@csrf_exempt
def callback(request, id):
    def verify_signature(response_data):
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        return client.utility.verify_payment_signature(response_data)

    if "razorpay_signature" in request.POST:
        payment_id = request.POST.get("razorpay_payment_id", "")
        provider_order_id = request.POST.get("razorpay_order_id", "")
        signature_id = request.POST.get("razorpay_signature", "")
        order = Order.objects.get(provider_order_id=provider_order_id)
        order.payment_id = payment_id
        order.signature_id = signature_id
        order.save()
        if verify_signature(request.POST):

            order.status = PaymentStatus.SUCCESS

            order.save()

            return redirect("status")
        else:
            order.status = PaymentStatus.FAILURE
            order.save()
            return render(request, "blog/payment1.html", context={"status": order.status})
    else:
        payment_id = json.loads(request.POST.get("error[metadata]")).get("payment_id")
        provider_order_id = json.loads(request.POST.get("error[metadata]")).get(
            "order_id"
        )
        order = Order.objects.get(provider_order_id=provider_order_id)
        order.payment_id = payment_id
        order.status = PaymentStatus.FAILURE
        order.save()
        return render(request, "blog/payment1.html", context={"status": order.status})


