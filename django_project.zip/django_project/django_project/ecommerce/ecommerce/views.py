from django.shortcuts import render, HttpResponse
def home1(request):
    return HttpResponse("this is my home page" )
def home(request):
    return render(request,"blog/index.html")
def about(request):
    return HttpResponse("this is my about page" "<a href='../gallery'>gallery</a>")
def gallery(request):
    return HttpResponse("this is my gallery page")